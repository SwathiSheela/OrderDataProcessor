﻿using OrderDataProcessor.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace OrderDataProcessor.Tests
{
    public class FileParserTests
    {
        private readonly FileParserService _fileParser;

        public FileParserTests()
        {
            _fileParser = new FileParserService();
        }

        [Fact]
        public void ParseCsvFile_ValidHeaderAndDetail_ReturnsCorrectRecords()
        {
            //Arrange
            var filePath = "./TestData/data.csv";

            //Act
            var result = _fileParser.ParseCsvFile(filePath);

            //Assert
            Assert.Equal(3, result.headers.Count);
            Assert.Equal("PO12345", result.headers[0].PurchaseOrderNumber);
            Assert.Equal("SupplierA", result.headers[0].Supplier);
            Assert.Equal("Los Angeles", result.headers[0].Destination);
            Assert.Equal(8, result.details.Count);
        }

        [Fact]
        public void ParseCsvFile_HeaderWithoutDestination_UsesDefaultDestination()
        {
            //Arrange
            var filePath = "./TestData/data.csv";

            //Act
            var result = _fileParser.ParseCsvFile(filePath);

            //Assert
            Assert.Equal("Melbourne AUMEL", result.headers[1].Destination);
        }

        [Fact]
        public void ParseCsvFile_InvalidLineNumber_ThrowsException()
        {            
            Assert.Throws<InvalidDataException>(() => _fileParser.ParseCsvFile("./TestData/data-duplicatelinenumber.csv"));
        }

        [Fact]
        public void ParseCsvFile_EmptyInput_ThrowsException()
        {
            Assert.Throws<InvalidDataException>(() => _fileParser.ParseCsvFile("./TestData/data-empty.csv"));
        }
    }
}
