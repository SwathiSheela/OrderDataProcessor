﻿using OrderDataProcessor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace OrderDataProcessor.Services
{
    public class XmlGeneratorService
    {
        public string GenerateXmlFromRawData(List<HeaderRecord> headers, List<DetailRecord> details)
        {
            var xmlStringBuilder = new StringBuilder();
            try
            {
                using (var xmlWriter = XmlWriter.Create(xmlStringBuilder, new XmlWriterSettings { Indent = true }))
                {
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("Orders");

                    foreach (var header in headers)
                    {
                        xmlWriter.WriteStartElement("Order");
                        xmlWriter.WriteElementString("PurchaseOrderNumber", header.PurchaseOrderNumber);
                        xmlWriter.WriteElementString("Supplier", header.Supplier);
                        xmlWriter.WriteElementString("Origin", header.Origin);
                        xmlWriter.WriteElementString("Destination", header.Destination);
                        xmlWriter.WriteElementString("CargoReadyDate", header.CargoReadyDate.ToString("o"));

                        foreach (var detail in details)
                        {
                            if (detail.PurchaseOrderNumber == header.PurchaseOrderNumber)
                            {
                                xmlWriter.WriteStartElement("Detail");
                                xmlWriter.WriteElementString("LineNumber", detail.LineNumber.ToString());
                                xmlWriter.WriteElementString("ItemDescription", detail.ItemDescription);
                                xmlWriter.WriteElementString("OrderQty", detail.OrderQty.ToString());
                                xmlWriter.WriteEndElement(); // Detail
                            }
                        }

                        xmlWriter.WriteEndElement(); // Order
                    }

                    xmlWriter.WriteEndElement(); // Orders
                    xmlWriter.WriteEndDocument();
                }

                return xmlStringBuilder.ToString();
            }
            catch
            {
                throw;

            }
        }
    }
}